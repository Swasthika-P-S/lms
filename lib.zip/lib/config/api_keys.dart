/// API Keys Configuration
/// 
/// IMPORTANT: This file contains sensitive API keys.
/// DO NOT commit this file to version control!
/// 
/// Add this file to .gitignore:
/// lib/config/api_keys.dart

class APIKeys {
  // Gemini AI API Key
  // Get your key from: https://makersuite.google.com/app/apikey
  static const String geminiApiKey = 'YOUR_GEMINI_API_KEY_HERE';
  
  // Firebase Configuration Keys
  // Get these from Firebase Console → Project Settings → Web App
  static const String firebaseApiKey = 'YOUR_FIREBASE_API_KEY_HERE';
  static const String firebaseProjectId = 'YOUR_PROJECT_ID_HERE';
  static const String firebaseMessagingSenderId = 'YOUR_SENDER_ID_HERE';
  static const String firebaseAppId = 'YOUR_APP_ID_HERE';
  
  // Optional: Analytics Measurement ID
  static const String firebaseMeasurementId = 'YOUR_MEASUREMENT_ID_HERE';
}

// TODO: After getting your API keys:
// 1. Replace all 'YOUR_*_HERE' placeholders with actual values
// 2. Make sure to add this file to .gitignore
// 3. Never commit API keys to Git
