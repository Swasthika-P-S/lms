class AppConstants {
  static const String appName = 'LearnHub';
  static const double borderRadius = 16.0;
  static const double cardPadding = 16.0;
  static const double spacing = 16.0;
}
